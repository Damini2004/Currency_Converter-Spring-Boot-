package com.currency.main.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class CurrencyController {

	@RequestMapping("/")
	public String request() {
		return "index";
	}
	
	@RequestMapping("/index")
	public String request_3() {
		return "base";
	}
	
	
	@RequestMapping("/request")
	public String request_2( @RequestParam("amount") double amount, @RequestParam("dropdown") String dropdown,@RequestParam("dropdown2") String dropdown2,Model m) {
		System.out.println(amount+" "+dropdown+" " +dropdown2);
	Double	d=amount;;
		if(dropdown.equalsIgnoreCase("INR")) {
			m.addAttribute("Currency_1","INR");
			if(dropdown2.equalsIgnoreCase("INR")) {
				d=amount;
				m.addAttribute("Currency_2","INR");
			}
if(dropdown2.equalsIgnoreCase("EURO")) {
	d=amount*0.011;
	m.addAttribute("Currency_2","EURO");
			}
if(dropdown2.equalsIgnoreCase("Dinar")) {
	d=amount*0.0037;
	m.addAttribute("Currency_2","Dinar");
}
		}
		
		if(dropdown.equalsIgnoreCase("EURO")) {
			m.addAttribute("Currency_1","EURO");
			if(dropdown2.equalsIgnoreCase("INR")) {
				d=amount*91.96;
				m.addAttribute("Currency_2","INR");
			}
if(dropdown2.equalsIgnoreCase("EURO")) {
	d=amount;
	m.addAttribute("Currency_2","EURO");

			}
if(dropdown2.equalsIgnoreCase("Dinar")) {
	d=amount*0.34;
	m.addAttribute("Currency_2","Dinar");
}
		}
		
		if(dropdown.equalsIgnoreCase("Dinar")) {
			m.addAttribute("Currency_1","Dinar");
			if(dropdown2.equalsIgnoreCase("INR")) {
				d=amount*270.65;
				m.addAttribute("Currency_2","INR");
			}
if(dropdown2.equalsIgnoreCase("EURO")) {
	d=amount*2.94;
	m.addAttribute("Currency_2","EURO");
			}
if(dropdown2.equalsIgnoreCase("Dinar")) {
	d=amount;
	m.addAttribute("Currency_2","Dinar");
}
		}
		m.addAttribute("rate", d.toString());
		return "Currency";
	}
	
}
