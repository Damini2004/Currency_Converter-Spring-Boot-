package com.currency.main.Entity;


public class CurrencyConvert {

	private String dropdown1;
	private String dropdown2;
	public String getDropdown1() {
		return dropdown1;
	}
	public void setDropdown1(String dropdown1) {
		this.dropdown1 = dropdown1;
	}
	public String getDropdown2() {
		return dropdown2;
	}
	public void setDropdown2(String dropdown2) {
		this.dropdown2 = dropdown2;
	}
	public CurrencyConvert(String dropdown1, String dropdown2) {
		super();
		this.dropdown1 = dropdown1;
		this.dropdown2 = dropdown2;
	}
	public CurrencyConvert() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "CurrencyConvert [dropdown1=" + dropdown1 + ", dropdown2=" + dropdown2 + "]";
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
